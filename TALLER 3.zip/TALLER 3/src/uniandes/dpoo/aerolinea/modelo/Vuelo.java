package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;

public class Vuelo {

	private String fecha;
	
	public Vuelo(Ruta ruta, String fecha, Avion avion){
	
	}

	public Ruta getRuta(){
		return Ruta;
	}

	public String getFecha(){
		return fecha;
	}
	
	public Avion getAvion(){
		return Avion;
	}
	
	public Collection<Tiquiete> getTiquetes(){
		return Collection<Tiquiete>;
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		
	}
	
	public boolean equals(Object obj) {
		return true;
	}
}
