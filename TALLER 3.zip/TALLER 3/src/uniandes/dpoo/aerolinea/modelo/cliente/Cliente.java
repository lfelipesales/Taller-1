package uniandes.dpoo.aerolinea.modelo.cliente;

public abstract class Cliente {

	public Cliente() {
		
	}
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agragarTiquete(Tiquete tiquete) {	
	}
	
	public int calcularValorTiquetes() {
		return 1;
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		
	}
	
}
