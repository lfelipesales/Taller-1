package uniandes.dpoo.aerolinea.modelo.tarifas;

public class CalculadoraTarifasTemporadaAlta {

	protected int COSTO_POR_KM = 1000;
	
	public int calcularCostoBase​(Vuelo vuelo,Cliente cliente) {

	}

	public double calcularPorcentajeDescuento​(Cliente cliente) {

	}
}
