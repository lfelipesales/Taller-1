package uniandes.dpoo.aerolinea.persistencia;

import java.io.IOException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public interface PersistenciaAerolinea {

	public void cargarTiquetes( String archivo, Aerolinea aerolinea ) throws IOException;
	
	public void salvarTiquetes( String archivo, Aerolinea aerolinea ) throws IOException;
}
