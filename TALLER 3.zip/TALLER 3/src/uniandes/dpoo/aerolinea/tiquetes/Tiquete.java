package uniandes.dpoo.aerolinea.tiquetes;

public class Tiquete {

	public String codigo;
	public int tarifa;
	public boolean usado;
	
	public Tiquete (String codigo, Vuelo vuelo, Cliente clienteComprador, int tarifa) {
		
	}
	
	public Cliente getCliente() {
		return clienteComprador;
	}
	
	public Vuelo getVuelo() {
		return vuelo;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public int getTarifa() {
		return tarifa;
	}
	
	public void marcarComoUsado(){
	}
	
	public boolean esUsado(){
		return usado;
	}
	
	
}
